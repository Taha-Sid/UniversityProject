package game;

import city.cs.engine.*;

public class Portal extends StaticBody {
    private static final Shape portalShape = new CircleShape(1);

    private static final BodyImage image =
            new BodyImage("data/portal.gif", 2f);

    public Portal(World world) {
        super(world);
        addImage(image);
        new SolidFixture(this, portalShape);

    }

}
