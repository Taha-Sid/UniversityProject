package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class GreenGoblin extends Walker implements StepListener {

    private static final Shape enemyShape = new PolygonShape(-0.901f,-0.588f, -0.329f,0.972f, 0.895f,0.796f, 0.887f,-0.664f, -0.669f,-0.984f);

    private static BodyImage enemyImage = new BodyImage("data/green_goblin/green_goblin_right.png", 2);
    private final int SPEED = 4;

    private float left, right;
    int RANGE;

    public GreenGoblin(World world, int r) {
        super(world, enemyShape);
        addImage(enemyImage);
        world.addStepListener(this);
        this.RANGE = r;
        startWalking(SPEED);
    }

    @Override
    public void setPosition(Vec2 position) {
        super.setPosition(position);
        left = position.x-RANGE;
        right = position.x+RANGE;
    }

    @Override
    public void preStep(StepEvent stepEvent) {
        if (getPosition().x > right){
            startWalking(-SPEED);
            removeAllImages();
            addImage(new BodyImage("data/green_goblin/green_goblin_left.png", 2));
        }
        if (getPosition().x < left){
            startWalking(SPEED);
            removeAllImages();
            addImage(new BodyImage("data/green_goblin/green_goblin_right.png", 2));
        }
    }

    @Override
    public void postStep(StepEvent stepEvent) {

    }
}
