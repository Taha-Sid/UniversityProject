package game;

import city.cs.engine.*;

public class Coin extends StaticBody {
    private static final Shape coinShape = new CircleShape(1);

    private static final BodyImage image =
            new BodyImage("data/coin.gif", 2);

    public Coin(World world) {
        super(world);
        addImage(image);

        new GhostlyFixture(this, coinShape);
    }
}