package game;

import city.cs.engine.*;

public class WebCollisionListener implements CollisionListener {

    private Web web;
    public static int enemiesDefeated = 0;

    public WebCollisionListener(Web web) {
        this.web = web;
    }

    @Override
    public void collide(CollisionEvent e) {
        e.getReportingBody().destroy();
        if(e.getOtherBody() instanceof GreenGoblin) {
            e.getOtherBody().destroy();
            enemiesDefeated++;

        }
        else if(e.getOtherBody() instanceof Loki) {
            e.getOtherBody().destroy();
            enemiesDefeated++;
        }
        else if(e.getOtherBody() instanceof Thanos) {
            e.getOtherBody().destroy();
            enemiesDefeated++;
        }

       }

}
