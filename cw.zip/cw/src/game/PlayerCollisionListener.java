package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import org.jbox2d.common.Vec2;

public class PlayerCollisionListener implements CollisionListener {

    private Player player;
    public static int health = 1000;
    public static boolean portalReached = false;

    public PlayerCollisionListener(Player player) {
        this.player = player;
    }

    @Override
    public void collide(CollisionEvent e) {
        if(e.getOtherBody() instanceof GreenGoblin) {
            if(health == 0) {
                e.getReportingBody().destroy();
            }
            health--;
            moveBack();

        }
        else if(e.getOtherBody() instanceof Loki) {
            if(health == 0) {
                e.getReportingBody().destroy();
            }
            health--;
            moveBack();
        }
        else if(e.getOtherBody() instanceof Thanos) {
            if(health == 0) {
                e.getReportingBody().destroy();
            }
            health--;
            moveBack();
        }
        else if(e.getOtherBody() instanceof Portal) {
            portalReached = true;
        }
       }

       public void moveBack() {
            if(PlayerKeyListener.direction == "right") {
                player.applyImpulse(new Vec2(-3, 0));
            }
            else {
                player.applyImpulse(new Vec2(3, 0));
            }
       }

}
