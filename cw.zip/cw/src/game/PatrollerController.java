package game;

import city.cs.engine.StepEvent;
import city.cs.engine.StepListener;
import city.cs.engine.Walker;
import city.cs.engine.World;
import org.jbox2d.common.Vec2;

public class PatrollerController extends Walker implements StepListener {

    private float left;
    private float right;
    private PatrollerController patroller;

    public PatrollerController(PatrollerController patroller, float left, float right) {
        super(new World());
        this.left = left;
        this.right = right;
        this.patroller = patroller;
    }

    @Override
    public void preStep(StepEvent stepEvent) {
        Vec2 pos = patroller.getPosition();
        if (pos.x <= left) {
            patroller.startWalking(1);
        } else if (pos.x >= right) {
            patroller.startWalking(-1);
        }
    }

    @Override
    public void postStep(StepEvent stepEvent) {

    }

}
