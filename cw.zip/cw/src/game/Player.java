package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Player extends Walker {
    private static final Shape playerShape = new PolygonShape(-0.879f,-0.936f, 0.897f,-0.936f, 0.885f,0.004f, 0.485f,0.984f, -0.419f,0.992f, -0.863f,-0.008f);

    private static final BodyImage image =
            new BodyImage("data/spiderman/spiderman_right.png", 2);

    public Player(World world) {
        super(world, playerShape);
        addImage(image);
        new SolidFixture(this, playerShape);
    }

    public void jump() {
        setLinearVelocity(getLinearVelocity().add(new Vec2(0, 6))); // Adjust the y-velocity to control the jump height
    }

    public void startWalking(float speed) {
        setLinearVelocity(new Vec2(speed, getLinearVelocity().y));
    }

    public void stopWalking() {
        setLinearVelocity(new Vec2(0, getLinearVelocity().y));
    }

}