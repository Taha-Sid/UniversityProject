package game;

import org.jbox2d.common.Vec2;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PlayerMouseListener extends MouseAdapter {

    private Player player;

    public PlayerMouseListener(Player player) {
        this.player = player;
    }

    public void mousePressed(MouseEvent e) {
        Web web = new Web(player.getWorld());
        if(PlayerKeyListener.direction == "right") {
            web.setPosition(new Vec2(player.getPosition().x + 3, player.getPosition().y));
            web.setGravityScale(0);
            web.startWalking(10);
        }
        else {
            web.setPosition(new Vec2(player.getPosition().x - 3, player.getPosition().y));
            web.setGravityScale(0);
            web.startWalking(-10);
        }
        WebCollisionListener webCollide = new WebCollisionListener(web);
        web.addCollisionListener(webCollide);
    }

}
