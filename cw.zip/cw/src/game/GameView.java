package game;

import city.cs.engine.UserView;

import javax.swing.*;
import java.awt.*;

public class GameView extends UserView {
    private Image background;
    private Image background2;

    public GameView(GameWorld world, int width, int height) {
        super(world, width, height);

        background = new ImageIcon("data/marvelBackground.gif").getImage();
        background2 = new ImageIcon("data/background.jpg").getImage();
    }

    @Override
    protected void paintBackground(Graphics2D g) {
        g.drawImage(background2, 0, 0, 800, 600, this);
    }

    @Override
    protected void paintForeground(Graphics2D g) {
        super.paintForeground(g);
        g.drawString("Coins Collected: ", 50, 15);
        StepListener2 st = new StepListener2();
        g.drawString(String.valueOf(StepListener2.coinsCollected), 140, 15);

        g.drawString("Enemies Defeated: ", 250, 15);
        g.drawString(String.valueOf(WebCollisionListener.enemiesDefeated), 355, 15);

        g.drawString("Health: ", 450, 15);
        g.drawString(String.valueOf(PlayerCollisionListener.health), 490, 15);

        if(PlayerCollisionListener.portalReached) {
            g.drawImage(background2, 0, 0, 800, 600, this);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Monospaced", Font.PLAIN, 100));
            g.drawString("YOU WIN", 200, 350);
        }

        if(PlayerCollisionListener.health < 0) {
            g.drawImage(background2, 0, 0, 800, 600, this);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Monospaced", Font.PLAIN, 100));
            g.drawString("YOU LOSE", 200, 350);
        }

    }

}