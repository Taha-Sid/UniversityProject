package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Web extends Walker {

    private static final Shape webShape = new CircleShape(0.5f);

    private static final BodyImage image =
            new BodyImage("data/web.png", 1);

    public Web(World world) {
        super(world, webShape);
        addImage(image);
        //new SolidFixture(this, webShape);

        //new GhostlyFixture(this, webShape);
    }

}
