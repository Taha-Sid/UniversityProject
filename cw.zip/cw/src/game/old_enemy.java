package game;

import city.cs.engine.*;

public class old_enemy extends Walker {
    private static final Shape enemyShape = new BoxShape(0.5f, 1);

    private static final BodyImage image =
            new BodyImage("data/enemy.png", 2f);

    private int maxX;
    private int minX;

    public old_enemy(World world, int maxX, int minX) {
        super(world, enemyShape);
        //addImage(Left);
        this.maxX = maxX;
        this.minX = minX;
    }

    public void walk() {
        if (getPosition().x >= maxX) {
            startWalking(-5);
            addImage(image);
        } else if (getPosition().x <= minX) {
            startWalking(5);
            addImage(image);

        }
    }
}