package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Thanos extends Walker implements StepListener {

    private static final Shape enemyShape = new PolygonShape(-0.682f,-0.98f, 0.694f,-0.884f, 0.622f,0.964f, -0.686f,0.956f, -0.722f,0.18f);

    private static BodyImage enemyImage = new BodyImage("data/thanos.gif", 2.5f);


    public Thanos(World world) {
        super(world, enemyShape);
        addImage(enemyImage);
        world.addStepListener(this);
    }

    @Override
    public void setPosition(Vec2 position) {
        super.setPosition(position);
    }

    @Override
    public void preStep(StepEvent stepEvent) {
    }

    @Override
    public void postStep(StepEvent stepEvent) {
    }
}
