package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class GameWorld extends World {

    private Player player;
    GreenGoblin enemies[] = new GreenGoblin[4];
    Coin coins[] = new Coin[6];

    public GameWorld() {
        super();

        //ground
        Shape ground = new BoxShape(20, 0.5f);
        StaticBody g = new StaticBody(this, ground);
        g.setPosition(new Vec2(0, -14.5f));

        //ceiling
        Shape ceiling = new BoxShape(20, 0.5f);
        StaticBody c = new StaticBody(this, ceiling);
        c.setPosition(new Vec2(0, 14.5f));

        //right wall
        Shape rightWall = new BoxShape(0.5f, 14.5f);
        StaticBody rw = new StaticBody(this, rightWall);
        rw.setPosition(new Vec2(19.5f, 0));

        //left wall
        Shape leftWall = new BoxShape(0.5f, 14.5f);
        StaticBody lw = new StaticBody(this, leftWall);
        lw.setPosition(new Vec2(-19.5f, 0));

        //floor 5
        Shape floor_5 = new BoxShape(17.5f, 0.5f);
        StaticBody f5 = new StaticBody(this, floor_5);
        f5.setPosition(new Vec2(-2.5f, 10.5f));

        //floor 4
        Shape floor_4 = new BoxShape(17.5f, 0.5f);
        StaticBody f4 = new StaticBody(this, floor_4);
        f4.setPosition(new Vec2(2.5f, 5.5f));

        //floor 3
        Shape floor_3 = new BoxShape(17.5f, 0.5f);
        StaticBody f3 = new StaticBody(this, floor_3);
        f3.setPosition(new Vec2(-2.5f, 0.5f));

        //floor 2
        Shape floor_2 = new BoxShape(17.5f, 0.5f);
        StaticBody f2 = new StaticBody(this, floor_2);
        f2.setPosition(new Vec2(2.5f, -4.5f));

        //floor 1
        Shape floor_1 = new BoxShape(17.5f, 0.5f);
        StaticBody f1 = new StaticBody(this, floor_1);
        f1.setPosition(new Vec2(-2.5f, -9.5f));

        // make the character
        player = new Player(this);
        player.setPosition(new Vec2(-5, -14.5f));

        GreenGoblin g1 = new GreenGoblin(this, 3);
        g1.setPosition(new Vec2(4,-8));

        GreenGoblin g2 = new GreenGoblin(this, 7);
        g2.setPosition(new Vec2(-6,2));

        Loki l1 = new Loki(this, 5);
        l1.setPosition(new Vec2(-2,-3));

        Loki l2 = new Loki(this, 7);
        l2.setPosition(new Vec2(-1,7));

        Thanos t1 = new Thanos(this);
        t1.setPosition(new Vec2(-13,12));

        Thanos t2 = new Thanos(this);
        t2.setPosition(new Vec2(-10,12));

        Thanos t3 = new Thanos(this);
        t3.setPosition(new Vec2(-7,12));

        Thanos t4 = new Thanos(this);
        t4.setPosition(new Vec2(-4,12));

        Thanos t5 = new Thanos(this);
        t5.setPosition(new Vec2(-1,12));

        Portal p = new Portal(this);
        p.setPosition(new Vec2(-16,12));

        Coin coin1 = new Coin(this);
        coin1.setPosition(new Vec2(-13,-12));

        StepListener2 st1 = new StepListener2();
        st1.setC(new Coin[] {coin1});
        st1.setP(player);
        addStepListener(st1);
//
        Coin coin2 = new Coin(this);
        coin2.setPosition(new Vec2(4, -7));

        StepListener2 st2 = new StepListener2();
        st2.setC(new Coin[] {coin2});
        st2.setP(player);
        addStepListener(st2);
//
        Coin coin3 = new Coin(this);
        coin3.setPosition(new Vec2(-8, -2));

        StepListener2 st3 = new StepListener2();
        st3.setC(new Coin[] {coin3});
        st3.setP(player);
        addStepListener(st3);
//
        Coin coin4 = new Coin(this);
        coin4.setPosition(new Vec2(7, 3));

        StepListener2 st4 = new StepListener2();
        st4.setC(new Coin[] {coin4});
        st4.setP(player);
        addStepListener(st4);
//
        Coin coin5 = new Coin(this);
        coin5.setPosition(new Vec2(-11, 8));

        StepListener2 st5 = new StepListener2();
        st5.setC(new Coin[] {coin5});
        st5.setP(player);
        addStepListener(st5);
//
        Coin coin6 = new Coin(this);
        coin6.setPosition(new Vec2(11, 13));

        StepListener2 st6 = new StepListener2();
        st6.setC(new Coin[] {coin6});
        st6.setP(player);
        addStepListener(st6);

        makeRightStaircase(15.5f, -13.5f);
        makeRightStaircase(15.5f, -3.5f);
        makeRightStaircase(15.5f, 6.5f);

        makeLeftStaircase(-15.5f, -8.5f);
        makeLeftStaircase(-15.5f, 1.5f);

    }

    private void makeRightStaircase(float x, float y) {
        float temp = x;
        Shape stair;
        StaticBody s;

        for(int j=0;j<4;j++) {
            for(int i=0;i<=4-j;i++) {
                stair = new BoxShape(0.5f, 0.5f);
                s = new StaticBody(this, stair);
                s.setPosition(new Vec2(x, y));
                x++;
            }
            x = temp + 1;
            temp = x;
            y++;
        }
    }

    private void makeLeftStaircase(float x, float y) {
        float temp = x;
        Shape stair;
        StaticBody s;

        for(int j=0;j<4;j++) {
            for(int i=0;i<4-j;i++) {
                stair = new BoxShape(0.5f, 0.5f);
                s = new StaticBody(this, stair);
                s.setPosition(new Vec2(x, y));
                x--;
            }
            x = temp - 1;
            temp = x;
            y++;
        }
    }

    public Player getPlayer() {
        return player;
    }

}