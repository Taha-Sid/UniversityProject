package game;

import city.cs.engine.StepEvent;
import city.cs.engine.StepListener;

public  class StepListener2 implements StepListener {

    Player p;

    Coin[] coins;
    public static int coinsCollected = 0;

    @Override
    public void preStep(StepEvent stepEvent){
        for(Coin c:coins) {
            if(p.intersects(c)) {
                c.destroy();
                coinsCollected++;
            }
        }
    }

    @Override
    public void postStep(StepEvent stepEvent) {

    }

    public void setP(Player p) {
        this.p = p;
    }

    public void setC(Coin[] c) {
        this.coins = c;
    }

//    public static int getCoinsCollected() { return coinsCollected;}

}
