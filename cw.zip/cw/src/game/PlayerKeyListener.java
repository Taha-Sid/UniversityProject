package game;

import city.cs.engine.BodyImage;
import city.cs.engine.World;
import org.jbox2d.common.Vec2;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PlayerKeyListener extends MouseAdapter implements KeyListener {

    private Player player;
    private int spriteCounter = 0;
    private int spriteNum = 1;
    public static String direction = "right";
    private boolean shoot;

    public PlayerKeyListener(Player p) {
        this.player = p;
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        update();
        if(e.getKeyChar() == 'w') {
            player.jump();
            //player.removeAllImages();
            //player.addImage(new BodyImage("data/p_3.png", 2f));
        }
        else if(e.getKeyChar() == 'd') {
            direction = "right";
            player.startWalking(10);
//            player.removeAllImages();
//            player.addImage(new BodyImage("data/spiderman/spiderman_right.png", 2f));
            if(spriteNum == 1) {
                player.removeAllImages();
                player.addImage(new BodyImage("data/spiderman/running_right/1.png", 2f));
            }
            if(spriteNum == 2) {
                player.removeAllImages();
                player.addImage(new BodyImage("data/spiderman/running_right/2.png", 2f));
            }
            if(spriteNum == 3) {
                player.removeAllImages();
                player.addImage(new BodyImage("data/spiderman/running_right/3.png", 2f));
            }
        }
        else if(e.getKeyChar() == 'a') {
            player.startWalking(-10);
            direction = "left";
//            player.removeAllImages();
//            player.addImage(new BodyImage("data/spiderman/spiderman_left.png", 2f));
            if(spriteNum == 1) {
                player.removeAllImages();
                player.addImage(new BodyImage("data/spiderman/running_left/1.png", 2f));
            }
            if(spriteNum == 2) {
                player.removeAllImages();
                player.addImage(new BodyImage("data/spiderman/running_left/2.png", 2f));
            }
            if(spriteNum == 3) {
                player.removeAllImages();
                player.addImage(new BodyImage("data/spiderman/running_left/3.png", 2f));
            }
        }
//        else if(e.getKeyChar() == 'p') {
//            Web web = new Web(player.getWorld());
//            if(direction == "right") {
//                web.setPosition(new Vec2(player.getPosition().x + 3, player.getPosition().y));
//                web.setGravityScale(0);
//                web.startWalking(10);
//            }
//            else {
//                web.setPosition(new Vec2(player.getPosition().x - 3, player.getPosition().y));
//                web.setGravityScale(0);
//                web.startWalking(-10);
//            }
//            WebCollisionListener webCollide = new WebCollisionListener(web);
//            web.addCollisionListener(webCollide);
//        }
        else if(e.getKeyChar() == 'h' && direction == "right") {
            if(player.getPosition().x > 20) {
                player.setPosition(new Vec2(20, player.getPosition().y));
            }
            player.setLinearVelocity(new Vec2(20,0));
            //player.applyForce(new Vec2(-10000,0));
        }
        else if(e.getKeyChar() == 'g' && direction == "left") {
            if(player.getPosition().x < -20) {
                player.setPosition(new Vec2(-20, player.getPosition().y));
            }
            player.setLinearVelocity(new Vec2(-20,0));
            //player.applyForce(new Vec2(10000,0));
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getKeyChar() == 'd') {
            player.stopWalking();
        }
        else if(e.getKeyChar() == 'a') {
            player.stopWalking();
        }
    }

    public void update() {
        spriteCounter++;
        if(spriteCounter > 3) { // runs 60fps and changes through the images
            if(spriteNum == 1) {
                spriteNum = 2;
            }
            else if (spriteNum == 2) {
                spriteNum = 3;
            }
            else {
                spriteNum = 1;
            }
            spriteCounter = 0;
        }
        PlayerCollisionListener playerCollide = new PlayerCollisionListener(player);
        player.addCollisionListener(playerCollide);
    }


//    @Override
//    public void keyPressed(KeyEvent e) {
//        int code = e.getKeyCode();
//        if (code == KeyEvent.VK_LEFT) {
//            player.startWalking(-20); // Move left
//            player.addImage(new BodyImage("data/p_3.png",4));
//        } else if (code == KeyEvent.VK_RIGHT) {
//            player.startWalking(20); // Move right
//            player.addImage(new BodyImage("data/p_2.png",4));
//        } else if (code == KeyEvent.VK_SPACE) {
//            player.jump(); // Jump
//        }
//    }
//
//    @Override
//    public void keyReleased(KeyEvent e) {
//        int code = e.getKeyCode();
//        if (code == KeyEvent.VK_LEFT || code == KeyEvent.VK_RIGHT) {
//            player.stopWalking(); // Stop horizontal movement
//        }
//    }

}