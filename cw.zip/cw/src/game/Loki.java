package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Loki extends Walker implements StepListener {

    private static final Shape enemyShape = new PolygonShape(-0.205f,-0.984f, 0.319f,-0.864f, 0.679f,-0.504f, 0.719f,0.976f, -0.681f,1.0f, -0.717f,0.28f, -0.669f,-0.968f);

    private static BodyImage enemyImage = new BodyImage("data/loki/loki_left.png", 2.5f);
    private final int SPEED = 4;

    private float left, right;
    int RANGE;

    public Loki(World world, int r) {
        super(world, enemyShape);
        addImage(enemyImage);
        world.addStepListener(this);
        this.RANGE = r;
        startWalking(-SPEED);
    }

    @Override
    public void setPosition(Vec2 position) {
        super.setPosition(position);
        left = position.x-RANGE;
        right = position.x+RANGE;
    }

    @Override
    public void preStep(StepEvent stepEvent) {
        if (getPosition().x > right){
            startWalking(-SPEED);
            removeAllImages();
            addImage(new BodyImage("data/loki/loki_left.png", 2.5f));
        }
        if (getPosition().x < left){
            startWalking(SPEED);
            removeAllImages();
            addImage(new BodyImage("data/loki/loki_right.png", 2.5f));
        }
    }

    @Override
    public void postStep(StepEvent stepEvent) {

    }
}
