package game;

import city.cs.engine.*;
import javax.swing.JFrame;

//import static jdk.jfr.internal.consumer.EventLog.update;

public class Game {

    public Game() {
        GameWorld world = new GameWorld();
        GameView view = new GameView(world, 800, 600);

        PlayerKeyListener playerKeyListener = new PlayerKeyListener(world.getPlayer());
        PlayerMouseListener playerMouseListener = new PlayerMouseListener(world.getPlayer());


        view.addKeyListener(playerKeyListener);
        view.addMouseListener(playerMouseListener);
        
//        view.setGridResolution(1);
        final JFrame frame = new JFrame("Run");
        frame.add(view);

        // enable the frame to quit the application
        // when the x button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
        // finally, make the frame visible
        frame.setVisible(true);

        //optional: uncomment this to make a debugging view
//        JFrame debugView = new DebugViewer(world, 800, 800);

        world.start();
        view.requestFocus();

    }

    public static void main(String[] args) {
        new Game();
    }

}
